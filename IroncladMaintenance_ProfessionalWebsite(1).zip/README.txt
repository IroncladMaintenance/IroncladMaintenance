IRONCLAD PROPERTY MAINTENANCE WEBSITE

Upload these files to your GitHub repository:
- index.html
- style.css
- assets/ironclad-logo.png
- assets/favicon.png

Steps:
1. Open your IroncladMaintenance GitHub repository.
2. Delete/replace the old index.html and style.css.
3. Upload this full contents, including the assets folder.
4. Commit to the main branch.
5. Wait a few minutes and open:
https://ironcladmaintenance.github.io/IroncladMaintenance/
